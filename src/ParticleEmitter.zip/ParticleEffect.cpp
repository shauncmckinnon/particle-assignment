#include "ParticleEffect.h"
#define RAW reinterpret_cast<char*>

ParticleEffect::ParticleEffect() {

}

ParticleEffect::ParticleEffect(int peID) {

}

ParticleEffect::~ParticleEffect() {

}

int ParticleEffect::getFileSize(const std::string &fileName) {
	std::ifstream file(fileName.c_str(), std::ifstream::in | std::ifstream::binary);

	if (!file.is_open())
	{
		return -1;
	}

	file.seekg(0, std::ios::end);
	int fileSize = file.tellg();
	file.close();

	return fileSize;
}

bool ParticleEffect::save() {
	// create file name
	std::string filename = name + ".dat";

	// get the file
	std::ofstream savefile(filename, std::ios::out | std::ios::binary);

	// check if the file didn't load
	if (!savefile) {
		std::cout << "Error in loading file." << std::endl;
		return false;
	}

	// write (or overwrite) the file
	savefile.seekp(0);

	// get the name size and write it and the data
	int nameSize = name.length() + 1;
	savefile.write(RAW(&nameSize), sizeof(int));
	savefile.write(name.c_str(), name.length() + 1);

	// get the vector size and write it
	int vectorSize = parEmitSettings.size();
	savefile.write(RAW(&vectorSize), sizeof(int));

	// iterate over the vector and write the values to the file
	int currentSeek = name.length() + 1;
	for (std::vector<ParEmitSettings>::const_iterator i = parEmitSettings.begin(); i != parEmitSettings.end(); i++) {
		savefile.write(RAW(&i), sizeof(ParEmitSettings));
	}

	if (savefile.bad()) {
		std::cout << "Particle Effect Settings could not be saved.";
		savefile.close();
		return false;
	}

	savefile.close();
	return true;
}

ParticleEffectSettings ParticleEffect::load(std::string filename) {
	// create the particle effect settings object
	ParticleEffectSettings peSettings;

	// get the file
	std::ifstream loadfile(filename, std::ios::in | std::ios::binary);

	// check if the file didn't load
	if (!loadfile) {
		std::cout << "Error in loading file." << std::endl;
	}

	// values
	int nameSize = 0;
	int vectorSize = 0;

	// read the file
	loadfile.read(RAW(&nameSize), sizeof(int));
	loadfile.read(RAW(&name), nameSize);
	loadfile.read(RAW(&vectorSize), sizeof(int));
	for (int i = 0; i < vectorSize; i++) {
		ParEmitSettings temp;
		loadfile.read(RAW(&temp), sizeof(ParEmitSettings));
		peSettings.parEmitSettings.push_back(temp);
	}

	loadfile.close();
	return peSettings;
}

std::ostream& operator << (std::ostream& stream, ParticleEffectSettings settings) {
	stream << "Name: " << settings.name << ", " << "Emitter Count: " << settings.parEmitSettings.size();
	return stream;
}